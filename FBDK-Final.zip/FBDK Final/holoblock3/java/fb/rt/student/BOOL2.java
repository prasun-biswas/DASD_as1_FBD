/* Copyright (c)2017 Rockwell Automation. All rights reserved. */
package fb.rt.student;
import fb.datatype.*;
import fb.rt.*;
import fb.rt.events.*;
import fb.rt.math.*;
/** FUNCTION_BLOCK BOOL2 (* Composite Function Block Type *)
  * @author JHC
  * @version 20170225/JHC - Generated.
  */
public class BOOL2 extends fb.rt.FBInstance {
/** Normal Execution Request */
public final EventOutput REQ = new EventOutput();
/** Execution Confirmation */
public final EventOutput CNF = new EventOutput();
/** FB and:FB_AND */
  protected FB_AND and = new FB_AND() ;
/** FB permit:E_PERMIT */
  protected E_PERMIT permit = new E_PERMIT() ;
/** VAR IN_1:BOOL */
  public BOOL IN_1 = new BOOL();
/** VAR IN_2:BOOL */
  public BOOL IN_2 = new BOOL();
/** Output event qualifier */
  public final BOOL QO = (BOOL)and.OUT;
/** The default constructor. */
public BOOL2(){
    super();
    REQ.connectTo(and.REQ);
    and.CNF.connectTo(permit.EI);
    permit.EO.connectTo(CNF);
    REQ.connectTo(and.REQ);
    and.CNF.connectTo(permit.EI);
    permit.EO.connectTo(CNF);
    and.connectIVNoException("IN1",IN_1);
    and.connectIVNoException("IN2",IN_2);
    permit.connectIVNoException("PERMIT",and.ovNamedNoException("OUT"));
    and.connectIVNoException("IN1",IN_1);
    and.connectIVNoException("IN2",IN_2);
    permit.connectIVNoException("PERMIT",and.ovNamedNoException("OUT"));
  }
	/**
 * {@inheritDoc}
 * @param newVar {@inheritDoc}
 */
@Override
protected void connectInternal(ANY newVar) {
  if(newVar == IN_1)
    and.connectIVNoException("IN1",IN_1);
  if(newVar == IN_2)
    and.connectIVNoException("IN2",IN_2);
  if(newVar == IN_1)
    and.connectIVNoException("IN1",IN_1);
  if(newVar == IN_2)
    and.connectIVNoException("IN2",IN_2);
}
/** start the FB instances. */
public void start( ){
    super.start();
  and.start();
  permit.start();
}
/** stop the FB instances. */
public void stop( ){
    super.stop();
  and.stop();
  permit.stop();
}
/** kill the FB instances. */
public void kill( ){
    super.kill();
  and.kill();
  permit.kill();
}
/** reset the FB instances. */
public void reset( ){
    super.reset();
  and.reset();
  permit.reset();
}
/** {@inheritDoc}
 * @param fbName {@inheritDoc}
 * @param r {@inheritDoc}
 * @throws FBRManagementException {@inheritDoc} */
  public void initialize(String fbName, Resource r)
  throws FBRManagementException{
    super.initialize(fbName,r);
    and.initialize("and",r);
    permit.initialize("permit",r);
}
}
